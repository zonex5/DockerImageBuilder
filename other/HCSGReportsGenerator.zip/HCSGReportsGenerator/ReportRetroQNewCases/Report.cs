﻿using IReport;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ReportRetroQNewCases
{
    public class Report : IGenericReport 
    {
        public string ReportName { get { return "Retro Queue New Cases"; } }

        public string ReportDescription { get { return "Retro Queue New Cases"; } }

        public string Version { get { return "1.0"; } }

        public string Template { get { return "template.xlsx"; } }

        public string SQLQuery { get { return "select * from pisea"; } }

        public string ReportFilename { get { return "ReportRetroQNewCases.xlsx"; } }

        public void Generate(ReportParams parameters)
        {
            ISheet sheet;

            var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("ReportRetroQNewCases.Resources.template.xlsx");
            XSSFWorkbook workbook = new XSSFWorkbook(stream);
            sheet = workbook.GetSheetAt(0);
            sheet.GetRow(0).GetCell(0).SetCellValue("Popa!");

            using (FileStream fileWriter = new FileStream(Path.Combine(parameters.DestinationDir, ReportFilename), FileMode.Create, FileAccess.ReadWrite, FileShare.None))
            {
                workbook.Write(fileWriter);
            }
        }
    }
}
