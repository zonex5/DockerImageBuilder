﻿using IReport;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCSGReportsGenerator
{
    class GenericReport 
    {
        public string ReportName { get; set; }

        public string ReportDescription { get; set; }

        public string SQLQuery { get; set; }

        public string ReportFilename { get; set; }

        public int DestinationRow { get; set; }
    }
}
