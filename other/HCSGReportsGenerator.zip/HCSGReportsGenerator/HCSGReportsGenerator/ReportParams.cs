﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCSGReportsGenerator
{
    public class ReportPresset
    {
        public bool SaveToOneSpreadsheet { get; set; }

        public string SpreadsheetFileName { get; set; }

        public string ReportsLocationFolder { get; set; }

        public bool PlaceToCurentDateFolder { get; set; }

        public List<String> SelectedReports { get; set; }

        public ReportPresset()
        {
            SelectedReports = new List<string>();
            ReportsLocationFolder = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        }
    }
}
