﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HCSGReportsGenerator
{
    public partial class ParamsForm : Form
    {
        private ReportPresset presset;

        public ParamsForm(ReportPresset presset)
        {
            InitializeComponent();
            this.presset = presset;

            tbFolder.Text = presset.ReportsLocationFolder;
            tbFilename.Text = presset.SpreadsheetFileName;
            cbSingleFile.Checked = presset.SaveToOneSpreadsheet;
            cbCurrentDate.Checked = presset.PlaceToCurentDateFolder;
        }

        private void cbSingleFile_CheckedChanged(object sender, EventArgs e)
        {
            tbFilename.Enabled = cbSingleFile.Checked;
        }

        private void btFolder_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                tbFolder.Text = dialog.SelectedPath;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(tbFilename.Text.Length == 0 && cbSingleFile.Checked)
            {
                MessageBox.Show("The file name can't be empty.", "Attention", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (tbFolder.Text.Length > 0)
                presset.ReportsLocationFolder = tbFolder.Text;
            presset.PlaceToCurentDateFolder = cbCurrentDate.Checked;
            presset.SaveToOneSpreadsheet = cbSingleFile.Checked;
            presset.SpreadsheetFileName = tbFilename.Text;
            DialogResult = DialogResult.OK;
        }
    }
}
