﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HCSGReportsGenerator
{
    public partial class ReportForm : Form
    {
        public ReportForm()
        {
            InitializeComponent();
        }

        private void tbRow_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (
                tbDescription.Text.Length == 0 ||
                tbFilename.Text.Length == 0 ||
                tbReportName.Text.Length == 0 ||
                tbRow.Text.Length == 0 ||
                tbSQLQuery.Text.Length == 0 ||
                tbTemplate.Text.Length == 0
                )
            {
                MessageBox.Show("All the fields are required.", "Attention", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            GenericReport report = new GenericReport();
            report.DestinationRow = Convert.ToInt16(tbRow.Text);
            report.ReportDescription = tbDescription.Text;
            report.ReportFilename = tbFilename.Text;
            report.ReportName = tbReportName.Text;
            report.SQLQuery = tbSQLQuery.Text;

            // copy template
            Directory.CreateDirectory("Report Templayts");
            File.Copy(tbTemplate.Text, "Report Templayts\\" + Path.GetFileNameWithoutExtension(report.ReportFilename) + ".xlsx");

            // create layout
            Directory.CreateDirectory("Report Layouts");
            string json = JsonConvert.SerializeObject(report, Formatting.Indented);
            string filename = "Report Layouts\\" + Path.GetFileNameWithoutExtension(report.ReportFilename) + ".report";
            File.WriteAllText(filename, json);

            DialogResult = DialogResult.OK;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void ReportForm_Shown(object sender, EventArgs e)
        {
            tbReportName.Focus();
        }

        private void btFolder_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "*.xlsx|*.xlsx";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                tbTemplate.Text = dialog.FileName;
            }
        }
    }
}
