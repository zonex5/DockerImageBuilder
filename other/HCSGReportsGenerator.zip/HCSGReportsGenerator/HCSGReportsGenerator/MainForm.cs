﻿using IReport;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HCSGReportsGenerator
{
    public partial class MainForm : Form
    {
        private Dictionary<string, IGenericReport> reportDic = new Dictionary<string, IGenericReport>();
        List<IGenericReport> reportsList = new List<IGenericReport>();

        ReportPresset ReportPresset;

        public MainForm()
        {
            InitializeComponent();

            Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");

            //-- try load configs   
            ReportPresset = new ReportPresset();
            SetGuiInfo();

            //-- load plugins
            LoadPlugins();

            /*list.Rows.Add(new object[] { true, "pisea i popa" });
            list.Rows.Add(new object[] { false, "pisea v pope" });
            list.Rows.Add(new object[] { false, "pisea i pisea" });
            list.Rows.Add(new object[] { true, "popa i popa" });*/

            reportsList.ForEach(r =>
            {
                list.Rows.Add(new object[] { false, r.ReportName });
            });
        }

        private void SetGuiInfo()
        {
            lbLocationFolder.Text = ReportPresset.ReportsLocationFolder;
        }

        private void LoadPlugins()
        {
            string[] pluginFiles = Directory.GetFiles(Application.StartupPath, "*.dll");

            foreach (string pluginPath in pluginFiles)
            {
                Assembly assembly = Assembly.LoadFrom(pluginPath);
                if (assembly != null)
                {
                    foreach (Type t in assembly.GetTypes())
                    {
                        foreach (Type i in t.GetInterfaces())
                        {
                            if (i == typeof(IGenericReport))
                            {
                                IGenericReport plugin = Activator.CreateInstance(t) as IGenericReport;
                                reportsList.Add(plugin);
                                reportDic.Add(plugin.ReportName, plugin);
                            }
                        }
                    }
                }
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            var item = reportDic[list.CurrentRow.Cells[1].Value.ToString()];

            QueryForm form = new QueryForm(item.SQLQuery);
            AddOwnedForm(form);
            form.StartPosition = FormStartPosition.CenterParent;
            form.ShowDialog();
        }

        private void list_SelectionChanged(object sender, EventArgs e)
        {
            if (list.CurrentRow != null)
            {
                lbViewQuery.Enabled = true;
                lbDescription.Text = reportDic[list.CurrentRow.Cells[1].Value.ToString()].ReportDescription;
            }
        }

        private void btGenerate_Click(object sender, EventArgs e)
        {
            /*ReportParams reportParams = new ReportParams() { DestinationDir = @"C:\Users\zonex\Desktop" };

            foreach (DataGridViewRow row in list.Rows)
            {
                if ((bool)row.Cells[0].Value)
                {
                    var item = reportDic[row.Cells[1].Value.ToString()];
                    item.Generate(reportParams);
                }
            }
            MessageBox.Show("ok");*/

        }

        private void btReportParams_Click(object sender, EventArgs e)
        {
            ParamsForm form = new ParamsForm(ReportPresset);
            AddOwnedForm(form);
            form.StartPosition = FormStartPosition.CenterParent;
            form.ShowDialog();
            SetGuiInfo();
        }

        private void btOpenPresset_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "*.presset|*.presset";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    ReportPresset = JsonConvert.DeserializeObject<ReportPresset>(File.ReadAllText(dialog.FileName));
                }
                catch
                {
                    ReportPresset = new ReportPresset();
                }

                // clear all checkboxes
                foreach (DataGridViewRow row in list.Rows)
                {
                    row.Cells[0].Value = false;
                }

                // set checkbox
                foreach (DataGridViewRow row in list.Rows)
                {
                    foreach (string item in ReportPresset.SelectedReports)
                    {
                        if (item.Equals(row.Cells[1].Value.ToString()))
                            row.Cells[0].Value = true;
                    }
                }

                // gui info
                SetGuiInfo();
                list.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }

        private void btSavePresset_Click(object sender, EventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Filter = "*.presset|*.presset";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                ReportPresset.SelectedReports.Clear();
                foreach (DataGridViewRow row in list.Rows)
                {
                    if ((bool)row.Cells[0].Value)
                    {
                        ReportPresset.SelectedReports.Add(row.Cells[1].Value.ToString());
                    }
                }
                try
                {
                    var json = JsonConvert.SerializeObject(ReportPresset, Formatting.Indented);
                    File.WriteAllText(dialog.FileName, json, Encoding.Default);
                }
                catch
                {
                    MessageBox.Show("The report presset can't be saved.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void cbSelectAll_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in list.Rows)
            {
                row.Cells[0].Value = cbSelectAll.Checked;
            }
        }

        private void list_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            list.CommitEdit(DataGridViewDataErrorContexts.Commit);
        }

        private void btSettings_Click(object sender, EventArgs e)
        {
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            ReportForm form = new ReportForm();
            AddOwnedForm(form);
            form.StartPosition = FormStartPosition.CenterParent;
            form.ShowDialog();
        }
    }
}
