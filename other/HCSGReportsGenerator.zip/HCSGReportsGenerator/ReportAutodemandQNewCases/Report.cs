﻿using IReport;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReportAutodemandQNewCases
{
    public class Report : IGenericReport
    {
        public string ReportName { get { return "Autodemand Queue New Cases"; } }

        public string ReportDescription { get { return "Autodemand Queue New Cases"; } }

        public string Version { get { return "1.0"; } }

        public string Template { get { return "template.xlsx"; } }

        public string SQLQuery { get { return "select * from pisea"; } }

        public string ReportFilename { get { return "ReportAutodemandQNewCases.xlsx"; } }

        public void Generate(ReportParams parameters)
        {
            ISheet sheet;

            var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("ReportAutodemandQNewCases.Resources.template.xlsx");
            XSSFWorkbook workbook = new XSSFWorkbook(stream);
            sheet = workbook.GetSheetAt(0);
            sheet.GetRow(0).GetCell(0).SetCellValue("Pisea!");

            using (FileStream fileWriter = new FileStream(Path.Combine(parameters.DestinationDir, ReportFilename), FileMode.Create, FileAccess.ReadWrite, FileShare.None))
            {
                workbook.Write(fileWriter);
            }
        }
    }
}
