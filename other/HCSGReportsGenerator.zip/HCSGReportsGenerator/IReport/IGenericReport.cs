﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IReport
{
	public class ReportParams
	{
		public SqlConnection Connection { get; set; }
		public string DestinationDir { get; set; }
	}

	public interface IGenericReport
	{
		string ReportName { get; } 

		string ReportDescription { get; } 

		string Version { get; }

		string Template { get; }

		string SQLQuery { get; }
		string ReportFilename { get; } 

		void Generate(ReportParams parameters);

		//Control MainControl { get; set; }
	}
}
